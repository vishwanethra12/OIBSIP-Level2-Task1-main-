## js-simple-calculator
this repository contains the task 2 of my web development and designing intership offered by oasis infobyte
### task 2
- a simple calculator built using html, css and javascript
- thank you...